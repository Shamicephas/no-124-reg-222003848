
package loginandsignup;


public class Loginandsignup {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
         login LoginFrame=new login();
         LoginFrame.setVisible(true);
         LoginFrame.pack();
         LoginFrame.setLocationRelativeTo(null);
    }
    
}
